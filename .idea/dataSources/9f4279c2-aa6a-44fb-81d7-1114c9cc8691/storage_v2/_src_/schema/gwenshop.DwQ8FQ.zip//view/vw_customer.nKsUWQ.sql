create definer = root@localhost view vw_customer as
select `gwenshop`.`user`.`id`          AS `id`,
       `gwenshop`.`user`.`fullname`    AS `fullname`,
       `gwenshop`.`user`.`email`       AS `email`,
       `gwenshop`.`user`.`passwd`      AS `passwd`,
       `gwenshop`.`user`.`addr`        AS `addr`,
       `gwenshop`.`user`.`phonenumber` AS `phonenumber`,
       `gwenshop`.`user`.`create_at`   AS `create_at`,
       `gwenshop`.`user`.`delete_at`   AS `delete_at`
from `gwenshop`.`user`
where (`gwenshop`.`user`.`roles` = 'Khách');

