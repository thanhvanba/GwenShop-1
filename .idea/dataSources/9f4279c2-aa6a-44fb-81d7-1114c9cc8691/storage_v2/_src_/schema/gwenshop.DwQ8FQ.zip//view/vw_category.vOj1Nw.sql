create definer = root@localhost view vw_category as
select `gwenshop`.`category`.`id`            AS `id`,
       `gwenshop`.`category`.`category_name` AS `category_name`,
       count(`gwenshop`.`product`.`id`)      AS `amount`,
       `gwenshop`.`category`.`delete_at`     AS `delete_at`
from (`gwenshop`.`category` join `gwenshop`.`product`
      on ((`gwenshop`.`category`.`id` = `gwenshop`.`product`.`category_id`)))
group by `gwenshop`.`category`.`category_name`;

