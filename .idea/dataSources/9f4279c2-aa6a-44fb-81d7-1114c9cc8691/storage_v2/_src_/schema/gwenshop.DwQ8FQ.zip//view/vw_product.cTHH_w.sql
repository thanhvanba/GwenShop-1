create definer = root@localhost view vw_product as
select `gwenshop`.`product`.`id`               AS `id`,
       `gwenshop`.`category`.`category_name`   AS `category_name`,
       `gwenshop`.`product`.`product_name`     AS `product_name`,
       `gwenshop`.`product`.`prod_description` AS `prod_description`,
       `gwenshop`.`product`.`amount`           AS `amount`,
       `gwenshop`.`product`.`hot_product`      AS `hot_product`,
       `gwenshop`.`product`.`price`            AS `price`,
       `gwenshop`.`product`.`delete_at`        AS `delete_at`
from `gwenshop`.`product`
         join `gwenshop`.`category`
where (`gwenshop`.`product`.`id` = `gwenshop`.`category`.`id`);

