create
    definer = root@localhost procedure InsertCustomer(IN fullname varchar(50), IN email varchar(50),
                                                      IN passwd varchar(20), IN addr varchar(200),
                                                      IN phonenumber varchar(10))
BEGIN
   insert into user(fullname, email, passwd, addr, phonenumber, salary, roles, create_at, delete_at)
   value(fullname, email, passwd, addr, phonenumber, null, 'Khách', current_date(), null);
END;

