create definer = root@localhost view vw_order as
select `gwenshop`.`orderlist`.`id`          AS `id`,
       `gwenshop`.`orderlist`.`userId`      AS `userId`,
       `gwenshop`.`orderlist`.`fullname`    AS `fullname`,
       `gwenshop`.`orderlist`.`addr`        AS `addr`,
       `gwenshop`.`orderlist`.`phonenumber` AS `phonenumber`,
       `gwenshop`.`orderlist`.`statusOrder` AS `statusOrder`,
       `order_price`.`price`                AS `price`,
       `gwenshop`.`orderlist`.`employee_id` AS `employee_id`,
       `gwenshop`.`orderlist`.`create_at`   AS `create_at`
from ((select `gwenshop`.`orderdetail`.`order_id`                                     AS `order_id`,
              sum((`gwenshop`.`product`.`price` * `gwenshop`.`orderdetail`.`amount`)) AS `price`
       from (`gwenshop`.`orderdetail` join `gwenshop`.`product`
             on ((`gwenshop`.`orderdetail`.`product_id` = `gwenshop`.`product`.`id`)))
       group by `gwenshop`.`orderdetail`.`order_id`) `order_price` join `gwenshop`.`orderlist`
      on ((`order_price`.`order_id` = `gwenshop`.`orderlist`.`id`)));

