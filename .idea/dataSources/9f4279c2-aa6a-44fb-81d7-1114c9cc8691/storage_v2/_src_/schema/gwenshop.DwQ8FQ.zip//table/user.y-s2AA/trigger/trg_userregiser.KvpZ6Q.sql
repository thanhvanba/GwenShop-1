create definer = root@localhost trigger trg_UserRegiser
    after insert
    on user
    for each row
begin
	if(NEW.roles = 'Khách')
		then insert into cart(userId) values(NEW.id);
    end if;
end;

